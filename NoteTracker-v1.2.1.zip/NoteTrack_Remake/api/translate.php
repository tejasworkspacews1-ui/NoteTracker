<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  http_response_code(204);
  exit;
}

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
$text = trim($data['text'] ?? '');
$source = trim($data['source'] ?? 'auto');
$target = trim($data['target'] ?? 'en');

if ($text === '') {
  http_response_code(400);
  echo json_encode(['error' => 'Missing text']);
  exit;
}

$apiKey = getenv('GOOGLE_TRANSLATE_API_KEY');
if (!$apiKey) {
  http_response_code(500);
  echo json_encode([
    'error' => 'Missing GOOGLE_TRANSLATE_API_KEY on the server',
    'hint' => 'Set a server-side Google Cloud Translation API key. Do not expose it in frontend code.'
  ]);
  exit;
}

$url = 'https://translation.googleapis.com/language/translate/v2?key=' . urlencode($apiKey);
$payload = [
  'q' => $text,
  'target' => $target,
  'format' => 'text'
];
if ($source !== 'auto') $payload['source'] = $source;

$ch = curl_init($url);
curl_setopt_array($ch, [
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
  CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_TIMEOUT => 30,
]);

$response = curl_exec($ch);
if ($response === false) {
  http_response_code(500);
  echo json_encode(['error' => curl_error($ch)]);
  curl_close($ch);
  exit;
}
$http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http >= 400) {
  http_response_code($http);
  echo $response;
  exit;
}

$json = json_decode($response, true);
$translated = $json['data']['translations'][0]['translatedText'] ?? '';
echo json_encode([
  'translatedText' => html_entity_decode($translated, ENT_QUOTES | ENT_HTML5, 'UTF-8')
], JSON_UNESCAPED_UNICODE);
?>
