# NoteTrack Remake

A premium-looking, mobile-friendly, offline-first universal tracking PWA built with:

- HTML
- CSS
- Vanilla JavaScript
- Bootstrap CDN
- IndexedDB
- Service Worker
- Web App Manifest

## What changed in this remake

This version is more animated, more responsive, and more flexible. It includes:

- a cinematic dashboard shell
- mobile bottom navigation
- adaptive record cards, list rows, kanban, timeline, and calendar views
- custom categories with dynamic fields
- pinned, favorite, archived, recent, and due-soon scopes
- attachments stored locally
- backup / restore
- templates
- offline support
- a real Google Cloud Translation proxy sample

## Run locally, no npm

Use any static server. For example:

```bash
python -m http.server 3000
```

Then open:

```text
http://localhost:3000
```

## Translation setup

The frontend sends translation requests to:

```text
/api/translate.php
```

That PHP proxy expects this server-side environment variable:

```text
GOOGLE_TRANSLATE_API_KEY
```

Do not place the key in frontend JavaScript.

## Offline support

- Records, categories, templates, and activity live in IndexedDB.
- UI preferences live in localStorage.
- The service worker caches the app shell and assets.
- When offline, the existing workspace still works.

## Notes

- This build is intentionally simple and lightweight.
- If you host it on HTTPS or localhost, PWA install works properly.
- You can change categories and field structures without touching code.

## Suggested next extensions

- local reminder scheduling with notification badges
- richer PDF metadata extraction
- drag-to-reorder cards
- synced remote backend
- team sharing
- field-level formulas and computed views
