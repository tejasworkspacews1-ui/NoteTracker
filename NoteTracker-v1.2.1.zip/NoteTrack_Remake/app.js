import {
  STORE, uid, nowISO,
  getAll, getById, put, remove,
  seedIfEmpty, logActivity, exportBundle, importBundle
} from './db.js';

const LANGUAGES = [
  ['auto', 'Auto detect'], ['en', 'English'], ['es', 'Spanish'], ['fr', 'French'], ['de', 'German'],
  ['hi', 'Hindi'], ['ja', 'Japanese'], ['ko', 'Korean'], ['pt', 'Portuguese'], ['ru', 'Russian'],
  ['zh', 'Chinese'], ['ar', 'Arabic'], ['it', 'Italian'], ['tr', 'Turkish'], ['nl', 'Dutch'], ['ta', 'Tamil']
];

const PRIORITIES = ['Low', 'Medium', 'High', 'Critical'];
const DEFAULT_STATUS = ['Open', 'Active', 'Waiting', 'Done'];

const state = {
  categories: [],
  records: [],
  templates: [],
  activity: [],
  view: localStorage.getItem('notetrack.view') || 'grid',
  sort: localStorage.getItem('notetrack.sort') || 'updatedAt-desc',
  search: '',
  activeScope: 'all',
  activeCategory: localStorage.getItem('notetrack.category') || 'all',
  filters: { status: '', priority: '', tag: '', onlyFav: false, onlyPinned: false, onlyDue: false },
  selectedAttachments: [],
  currentRecordId: null,
};

const el = {};
let recordModal, categoryModal, settingsModal, translateModal, templatesModal, pickerModal, mobileDrawer;

const $ = (id) => document.getElementById(id);
const esc = (s = '') => String(s).replace(/[&<>"]/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]));
const titleCase = (s = '') => s ? s[0].toUpperCase() + s.slice(1) : '';
const priorityWeight = (p) => ({ Critical: 4, High: 3, Medium: 2, Low: 1 }[p] || 0);
const dateFmt = (v, opt = {}) => v ? new Intl.DateTimeFormat(undefined, opt).format(new Date(v)) : '—';
const shortDate = (v) => v ? dateFmt(v, { month: 'short', day: 'numeric' }) : '';
const localDT = (v) => {
  if (!v) return '';
  const d = new Date(v);
  const tz = d.getTimezoneOffset() * 60000;
  return new Date(d.getTime() - tz).toISOString().slice(0, 16);
};
const arrayify = (v) => Array.isArray(v) ? v : String(v || '').split(',').map(x => x.trim()).filter(Boolean);
const categoryById = (id) => state.categories.find(c => c.id === id);
const recordById = (id) => state.records.find(r => r.id === id);
const templateById = (id) => state.templates.find(t => t.id === id);

function toast(message, kind = 'primary') {
  const host = $('toastArea');
  const node = document.createElement('div');
  node.className = 'toast show';
  node.innerHTML = `
    <div class="toast-header border-0">
      <strong class="me-auto">NoteTrack</strong>
      <small>${kind === 'danger' ? 'alert' : 'now'}</small>
      <button class="btn-close btn-close-white ms-2" data-close-toast></button>
    </div>
    <div class="toast-body">${esc(message)}</div>
  `;
  host.appendChild(node);
  node.querySelector('[data-close-toast]').onclick = () => node.remove();
  setTimeout(() => node.remove(), 2500);
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  localStorage.setItem('notetrack.theme', theme);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', theme === 'dark' ? '#060816' : '#eef3ff');
  $('btnThemeToggle').innerHTML = theme === 'dark' ? '<i class="bi bi-moon-stars"></i>' : '<i class="bi bi-sun"></i>';
}
function applyAccent(color) {
  document.documentElement.style.setProperty('--accent', color);
  localStorage.setItem('notetrack.accent', color);
}
function setConnection(online) {
  const chip = $('connectionChip');
  chip.classList.toggle('offline', !online);
  chip.innerHTML = online
    ? '<span class="dot"></span><span>Online</span>'
    : '<span class="dot"></span><span>Offline</span>';
  $('offlinePill').textContent = online ? 'Online' : 'Offline';
  $('liveModeText').textContent = online ? 'Synced mode' : 'Local mode';
}
function categoryStages(cat) {
  const stages = arrayify(cat?.stages);
  return stages.length ? stages : DEFAULT_STATUS;
}
function categoryFields(cat) {
  return Array.isArray(cat?.fields) ? cat.fields : [];
}
function recordText(r) {
  const cat = categoryById(r.categoryId);
  const values = Object.values(r.values || {}).flatMap(v => Array.isArray(v) ? v : [v]).join(' ');
  return [r.title, r.notes, r.status, r.priority, r.url, (r.tags || []).join(' '), values, cat?.name, cat?.description].filter(Boolean).join(' ').toLowerCase();
}
function matchesFilters(r) {
  if (state.activeScope === 'favorites' && !r.favorite) return false;
  if (state.activeScope === 'pinned' && !r.pinned) return false;
  if (state.activeScope === 'archive' && !r.archived) return false;
  if (state.activeScope === 'recent') {
    const days = (Date.now() - new Date(r.updatedAt).getTime()) / 86400000;
    if (days > 14) return false;
  }
  if (state.activeCategory !== 'all' && r.categoryId !== state.activeCategory) return false;
  if (state.search.trim() && !recordText(r).includes(state.search.trim().toLowerCase())) return false;
  if (state.filters.status && String(r.status || '').toLowerCase() !== state.filters.status.toLowerCase()) return false;
  if (state.filters.priority && String(r.priority || '').toLowerCase() !== state.filters.priority.toLowerCase()) return false;
  if (state.filters.tag && !(r.tags || []).some(t => t.toLowerCase().includes(state.filters.tag.toLowerCase()))) return false;
  if (state.filters.onlyFav && !r.favorite) return false;
  if (state.filters.onlyPinned && !r.pinned) return false;
  if (state.filters.onlyDue) {
    const d = r.dueAt || r.values?.due || r.reminderAt;
    if (!d) return false;
    const t = new Date(d).getTime();
    if (Number.isNaN(t) || t < Date.now() || t > Date.now() + 7 * 86400000) return false;
  }
  return true;
}
function visibleRecords() {
  const list = state.records.filter(matchesFilters);
  const [key, dir] = state.sort.split('-');
  const mul = dir === 'asc' ? 1 : -1;
  list.sort((a, b) => {
    if (key === 'title') return a.title.localeCompare(b.title) * mul;
    if (key === 'priority') return (priorityWeight(a.priority) - priorityWeight(b.priority)) * mul;
    return (new Date(a[key] || 0) - new Date(b[key] || 0)) * mul;
  });
  return list;
}
function recordCount(categoryId) {
  return state.records.filter(r => r.categoryId === categoryId).length;
}

function currentCategory() {
  return state.activeCategory === 'all' ? null : categoryById(state.activeCategory);
}

function loadPreferences() {
  applyTheme(localStorage.getItem('notetrack.theme') || 'dark');
  applyAccent(localStorage.getItem('notetrack.accent') || '#7c8cff');
  $('defaultLanguage').value = localStorage.getItem('notetrack.lang') || 'en';
  $('translateEndpoint').value = localStorage.getItem('notetrack.translateEndpoint') || '/api/translate.php';
}

function renderCategories() {
  const categoryButtons = [
    `<button class="category-item ${state.activeCategory === 'all' ? 'active' : ''}" data-category-id="all">
      <span class="category-meta"><span class="category-icon" style="background:linear-gradient(135deg,var(--accent),#9a7cff)"><i class="bi bi-grid-1x2"></i></span><span class="category-name">All records</span></span>
      <span class="category-count">${state.records.length}</span>
    </button>`,
    ...state.categories.map(c => `
      <button class="category-item ${state.activeCategory === c.id ? 'active' : ''}" data-category-id="${c.id}">
        <span class="category-meta"><span class="category-icon" style="background:${c.color || 'var(--accent)'}"><i class="bi ${c.icon || 'bi-folder2'}"></i></span><span class="category-name">${esc(c.name)}</span></span>
        <span class="category-count">${recordCount(c.id)}</span>
      </button>
    `)
  ].join('');
  $('categoryList').innerHTML = categoryButtons;
  $('mobileCategoryList').innerHTML = categoryButtons;
  $('categoryPickerList').innerHTML = state.categories.map(c => `
    <button class="nav-card" data-create-in-category="${c.id}">
      <i class="bi ${c.icon || 'bi-folder2'}"></i>
      <span>${esc(c.name)}</span>
    </button>
  `).join('');

  document.querySelectorAll('[data-category-id]').forEach(btn => {
    btn.onclick = () => {
      state.activeCategory = btn.dataset.categoryId;
      localStorage.setItem('notetrack.category', state.activeCategory);
      state.activeScope = 'all';
      refreshNav();
      renderAll();
    };
  });
  document.querySelectorAll('[data-create-in-category]').forEach(btn => {
    btn.onclick = () => {
      pickerModal.hide();
      openRecordModal(null, btn.dataset.createInCategory);
    };
  });

  $('activeCategoryLabel').textContent = state.activeCategory === 'all' ? 'All records' : (currentCategory()?.name || 'All records');
}
function refreshNav() {
  document.querySelectorAll('[data-nav]').forEach(btn => btn.classList.toggle('active', btn.dataset.nav === state.activeScope));
  document.querySelectorAll('[data-mobile-nav]').forEach(btn => btn.classList.toggle('active', btn.dataset.mobileNav === state.activeScope));
}
function renderFilters() {
  const cat = currentCategory();
  const statuses = [''].concat(categoryStages(cat));
  $('statusFilter').innerHTML = `<option value="">All status</option>` + statuses.filter(Boolean).map(s => `<option value="${esc(s)}">${esc(s)}</option>`).join('');
  $('priorityFilter').innerHTML = `<option value="">All priority</option>` + PRIORITIES.map(p => `<option value="${p}">${p}</option>`).join('');
}
function renderStats() {
  $('statRecords').textContent = state.records.length;
  $('statCategories').textContent = state.categories.length;
  $('statPinned').textContent = state.records.filter(r => r.pinned).length;
  $('statFavorites').textContent = state.records.filter(r => r.favorite).length;
  $('statDueSoon').textContent = state.records.filter(r => {
    const due = r.dueAt || r.values?.due || r.reminderAt;
    if (!due) return false;
    const t = new Date(due).getTime();
    return t >= Date.now() && t <= Date.now() + 7 * 86400000;
  }).length;

  const reminders = state.records.filter(r => r.reminderAt && new Date(r.reminderAt).getTime() <= Date.now() && !r.archived).length;
  $('reminderCount').textContent = reminders;

  if (navigator.storage?.estimate) {
    navigator.storage.estimate().then(({ usage = 0, quota = 1 }) => {
      const pct = Math.min(100, Math.round((usage / quota) * 100));
      $('storageText').textContent = `${pct}%`;
      $('storageBar').style.width = `${pct}%`;
    }).catch(() => { $('storageText').textContent = '—'; });
  }
}
function renderActivity() {
  $('activityList').innerHTML = state.activity.slice(0, 6).map(a => `
    <div class="mini-item">
      <div>
        <div class="mini-item-title">${esc(a.message)}</div>
        <div class="mini-item-sub">${dateFmt(a.createdAt, { dateStyle: 'medium', timeStyle: 'short' })}</div>
      </div>
      <span class="pill">${esc(titleCase(a.type))}</span>
    </div>
  `).join('') || '<div class="muted-copy">No activity yet.</div>';
}
function renderHighlights() {
  const pinned = state.records.filter(r => r.pinned).slice(0, 4);
  const recent = [...state.records].sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt)).slice(0, 4);
  const mix = [...pinned, ...recent].filter((v, i, arr) => arr.findIndex(x => x.id === v.id) === i).slice(0, 6);
  $('highlightsList').innerHTML = mix.map(r => `
    <div class="mini-item">
      <div>
        <div class="mini-item-title">${esc(r.title)}</div>
        <div class="mini-item-sub">${esc(categoryById(r.categoryId)?.name || 'Uncategorized')}</div>
      </div>
      <button class="btn btn-soft btn-sm" data-open-record="${r.id}">Open</button>
    </div>
  `).join('') || '<div class="muted-copy">Pin records to see them here.</div>';
}
function renderTemplates() {
  $('templatesList').innerHTML = state.templates.map(t => `
    <div class="mini-item">
      <div>
        <div class="mini-item-title">${esc(t.name)}</div>
        <div class="mini-item-sub">${esc(categoryById(t.categoryId)?.name || 'Template')}</div>
      </div>
      <div class="mini-actions">
        <button class="btn btn-soft btn-sm" data-use-template="${t.id}">Use</button>
        <button class="btn btn-soft btn-sm" data-delete-template="${t.id}">Delete</button>
      </div>
    </div>
  `).join('') || '<div class="muted-copy">Save a record as a template and reuse it later.</div>';
}
function renderSummary() {
  const visible = visibleRecords();
  $('summaryPill').textContent = `${visible.length} items visible`;
  $('workspaceTitle').textContent =
    state.activeScope === 'favorites' ? 'Favorites' :
    state.activeScope === 'pinned' ? 'Pinned' :
    state.activeScope === 'recent' ? 'Recent' :
    state.activeScope === 'archive' ? 'Archive' :
    state.activeCategory === 'all' ? 'Everything' : (currentCategory()?.name || 'Everything');
}
function renderEmptyState() {
  const visible = visibleRecords();
  const empty = $('emptyState');
  if (visible.length) {
    empty.classList.add('d-none');
    return;
  }
  empty.classList.remove('d-none');
  empty.innerHTML = `
    <div class="display-6 mb-2"><i class="bi bi-inboxes"></i></div>
    <h3>No records here</h3>
    <p>Try a different category, clear filters, or create a custom structure for whatever you want to track.</p>
    <div class="d-flex flex-wrap gap-2 justify-content-center mt-2">
      <button class="btn btn-primary" id="btnEmptyAdd">Create record</button>
      <button class="btn btn-soft" id="btnEmptyCategory">Create category</button>
    </div>
  `;
  $('btnEmptyAdd').onclick = () => startQuickCreate();
  $('btnEmptyCategory').onclick = () => openCategoryModal();
}
function renderCards(records) {
  return `<div class="record-grid">${records.map(r => {
    const cat = categoryById(r.categoryId);
    const tags = (r.tags || []).slice(0, 4).map(t => `<span class="pill">#${esc(t)}</span>`).join('');
    const fields = categoryFields(cat).slice(0, 3).map(f => {
      const v = r.values?.[f.key];
      if (v === undefined || v === '' || v === null || v === false) return '';
      return `<span class="pill">${esc(f.label)}: ${esc(Array.isArray(v) ? v.join(', ') : String(v))}</span>`;
    }).filter(Boolean).join('');
    return `
      <article class="record-card" draggable="true" data-record-id="${r.id}" style="--accent:${cat?.color || 'var(--accent)'}">
        <div class="record-strip"></div>
        <div class="record-inner">
          <div class="record-top">
            <div>
              <h3 class="record-title">${esc(r.title)}</h3>
              <div class="muted-copy mt-1">${esc(cat?.name || 'Uncategorized')}</div>
            </div>
            <div class="mini-actions">
              ${r.favorite ? '<span class="pill"><i class="bi bi-heart-fill"></i></span>' : ''}
              ${r.pinned ? '<span class="pill"><i class="bi bi-pin-angle-fill"></i></span>' : ''}
              ${r.archived ? '<span class="pill">Archived</span>' : ''}
            </div>
          </div>
          <div class="record-meta">
            <span class="pill">${esc(r.status || 'No status')}</span>
            <span class="pill">${esc(r.priority || 'Low')}</span>
            ${r.dueAt ? `<span class="pill"><i class="bi bi-calendar-event"></i> ${shortDate(r.dueAt)}</span>` : ''}
            ${r.reminderAt ? `<span class="pill"><i class="bi bi-bell"></i> ${shortDate(r.reminderAt)}</span>` : ''}
          </div>
          <div class="record-body">${esc(r.notes || 'No notes yet. Add context, links, refs, or a short summary.').replace(/\n/g, '<br>')}</div>
          <div class="record-meta">${tags}${fields}</div>
          <div class="record-actions">
            <button class="btn btn-soft btn-sm" data-open-record="${r.id}"><i class="bi bi-pencil-square me-1"></i>Edit</button>
            <button class="btn btn-soft btn-sm" data-duplicate-record="${r.id}"><i class="bi bi-copy me-1"></i>Copy</button>
            <button class="btn btn-soft btn-sm" data-toggle-pin="${r.id}">${r.pinned ? 'Unpin' : 'Pin'}</button>
            <button class="btn btn-soft btn-sm" data-toggle-fav="${r.id}">${r.favorite ? 'Unsave' : 'Favorite'}</button>
          </div>
        </div>
      </article>
    `;
  }).join('')}</div>`;
}
function renderRows(records) {
  return records.map(r => {
    const cat = categoryById(r.categoryId);
    return `
      <div class="record-row" data-record-id="${r.id}">
        <div>
          <div class="row-title">${esc(r.title)}</div>
          <div class="row-sub">${esc(cat?.name || 'Uncategorized')} • ${esc((r.tags || []).slice(0,3).join(', ') || 'no tags')}</div>
        </div>
        <div><span class="pill">${esc(r.status || 'No status')}</span></div>
        <div><span class="pill">${esc(r.priority || 'Low')}</span></div>
        <div class="mini-actions"><button class="btn btn-soft btn-sm" data-open-record="${r.id}">Open</button></div>
      </div>`;
  }).join('');
}
function renderTimeline(records) {
  return `<div class="timeline">${records.map(r => `
    <div class="timeline-item" data-record-id="${r.id}">
      <div class="timeline-date">${dateFmt(r.dueAt || r.reminderAt || r.updatedAt || r.createdAt)}</div>
      <div>
        <div><span class="timeline-dot"></span><strong>${esc(r.title)}</strong></div>
        <div class="muted-copy mt-1">${esc((categoryById(r.categoryId)?.name || 'Uncategorized') + ' • ' + (r.status || 'No status'))}</div>
        <div class="mini-actions mt-2"><button class="btn btn-soft btn-sm" data-open-record="${r.id}">Open</button></div>
      </div>
    </div>`).join('')}</div>`;
}
function renderCalendar(records) {
  const now = new Date();
  const first = new Date(now.getFullYear(), now.getMonth(), 1);
  const start = new Date(first);
  start.setDate(first.getDate() - first.getDay());
  const days = Array.from({ length: 42 }, (_, i) => {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    return d;
  });
  const headers = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => `<div class="calendar-head">${d}</div>`).join('');
  const cells = days.map(d => {
    const sameDay = records.filter(r => [r.dueAt, r.reminderAt, r.createdAt, r.updatedAt].some(v => v && new Date(v).toDateString() === d.toDateString())).slice(0, 3);
    return `
      <div class="calendar-cell ${d.getMonth() === now.getMonth() ? '' : 'muted'}">
        <div class="calendar-day"><span>${d.getDate()}</span><span class="count-chip">${sameDay.length}</span></div>
        <div class="calendar-badges">${sameDay.map(r => `<span class="pill">${esc(r.title.slice(0, 12))}</span>`).join('')}</div>
      </div>`;
  }).join('');
  return `<div class="calendar">${headers}${cells}</div>`;
}
function renderRecords() {
  const visible = visibleRecords();
  renderSummary();
  renderEmptyState();
  const root = $('recordsContainer');
  if (!visible.length) {
    root.innerHTML = '';
    return;
  }
  if (state.view === 'list') root.innerHTML = renderRows(visible);
  else if (state.view === 'kanban') {
    const cat = currentCategory() || state.categories[0];
    const statuses = categoryStages(cat);
    root.innerHTML = `<div class="board">${statuses.map(status => {
      const items = visible.filter(r => (r.status || statuses[0]) === status);
      return `
        <div class="board-col">
          <div class="board-head"><strong>${esc(status)}</strong><span class="count-chip">${items.length}</span></div>
          <div class="board-drop" data-drop-status="${esc(status)}">${items.map(r => `
            <div class="kanban-card" draggable="true" data-record-id="${r.id}">
              <div class="row-title">${esc(r.title)}</div>
              <div class="row-sub">${esc(categoryById(r.categoryId)?.name || 'Uncategorized')}</div>
              <div class="record-meta mt-2"><span class="pill">${esc(r.priority || 'Low')}</span>${r.dueAt ? `<span class="pill">${shortDate(r.dueAt)}</span>` : ''}</div>
            </div>
          `).join('') || '<div class="muted-copy">Drop cards here.</div>'}</div>
        </div>`;
    }).join('')}</div>`;
    bindKanbanDrag();
  } else if (state.view === 'timeline') {
    root.innerHTML = renderTimeline(visible);
  } else if (state.view === 'calendar') {
    root.innerHTML = renderCalendar(visible);
  } else {
    root.innerHTML = renderCards(visible);
  }
  bindRecordActions();
}
function bindRecordActions() {
  document.querySelectorAll('[data-open-record]').forEach(btn => btn.onclick = () => openRecordModal(btn.dataset.openRecord));
  document.querySelectorAll('[data-duplicate-record]').forEach(btn => btn.onclick = () => duplicateRecord(btn.dataset.duplicateRecord));
  document.querySelectorAll('[data-toggle-pin]').forEach(btn => btn.onclick = () => toggleFlag(btn.dataset.togglePin, 'pinned'));
  document.querySelectorAll('[data-toggle-fav]').forEach(btn => btn.onclick = () => toggleFlag(btn.dataset.toggleFav, 'favorite'));
}
function bindKanbanDrag() {
  document.querySelectorAll('.kanban-card').forEach(card => {
    card.addEventListener('dragstart', ev => ev.dataTransfer.setData('text/plain', card.dataset.recordId));
  });
  document.querySelectorAll('[data-drop-status]').forEach(zone => {
    zone.addEventListener('dragover', ev => ev.preventDefault());
    zone.addEventListener('drop', async ev => {
      ev.preventDefault();
      const id = ev.dataTransfer.getData('text/plain');
      const record = recordById(id);
      if (!record) return;
      record.status = zone.dataset.dropStatus;
      record.updatedAt = nowISO();
      await put(STORE.records, record);
      await logActivity('update', `Moved "${record.title}" to ${record.status}`, record.id);
      await reloadData();
      renderAll();
      toast(`Moved to ${record.status}`);
    });
  });
}
function renderAll() {
  renderCategories();
  renderFilters();
  renderStats();
  renderActivity();
  renderHighlights();
  renderTemplates();
  renderRecords();
  refreshNav();
  $('lastSavedPill').textContent = `Saved ${new Intl.DateTimeFormat(undefined, { hour: '2-digit', minute: '2-digit' }).format(new Date())}`;
}

function fieldInput(field, value = '') {
  const key = esc(field.key || '');
  const label = esc(field.label || 'Field');
  const req = field.required ? 'required' : '';
  let input = '';
  switch ((field.type || 'text').toLowerCase()) {
    case 'number':
      input = `<input class="form-control" data-field-key="${key}" type="number" value="${esc(value)}" placeholder="${esc(field.placeholder || '')}" ${req}>`;
      break;
    case 'date':
      input = `<input class="form-control" data-field-key="${key}" type="date" value="${esc(value)}" ${req}>`;
      break;
    case 'time':
      input = `<input class="form-control" data-field-key="${key}" type="time" value="${esc(value)}" ${req}>`;
      break;
    case 'datetime':
      input = `<input class="form-control" data-field-key="${key}" type="datetime-local" value="${esc(value)}" ${req}>`;
      break;
    case 'select':
    case 'dropdown':
      input = `<select class="form-select" data-field-key="${key}" ${req}><option value="">Choose…</option>${arrayify(field.options).map(o => `<option ${String(o) === String(value) ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select>`;
      break;
    case 'checkbox':
      input = `<div class="form-check"><input class="form-check-input" data-field-key="${key}" type="checkbox" ${value ? 'checked' : ''}><label class="form-check-label">Enabled</label></div>`;
      break;
    case 'rating':
      input = `<select class="form-select" data-field-key="${key}">${[1,2,3,4,5].map(i => `<option value="${i}" ${Number(value)===i?'selected':''}>${'★'.repeat(i)}</option>`).join('')}</select>`;
      break;
    case 'rich':
    case 'textarea':
      input = `<textarea class="form-control" rows="3" data-field-key="${key}" ${req}>${esc(value)}</textarea>`;
      break;
    default:
      input = `<input class="form-control" data-field-key="${key}" type="text" value="${esc(value)}" placeholder="${esc(field.placeholder || '')}" ${req}>`;
  }
  return `<div class="record-field"><label>${label}${field.required ? ' <span class="field-badge">required</span>' : ''}</label>${input}</div>`;
}
function buildDynamicFields(cat, values = {}) {
  const fields = categoryFields(cat);
  return fields.length ? fields.map(f => fieldInput(f, values[f.key] ?? '')).join('') : '<div class="muted-copy">No custom fields yet. Add some in the structure designer.</div>';
}
function collectValues(root) {
  const values = {};
  root.querySelectorAll('[data-field-key]').forEach(node => {
    values[node.dataset.fieldKey] = node.type === 'checkbox' ? node.checked : node.value;
  });
  return values;
}
function openRecordModal(recordId = null, categoryId = null) {
  state.currentRecordId = recordId;
  state.selectedAttachments = [];
  const record = recordId ? recordById(recordId) : null;
  const cat = categoryId ? categoryById(categoryId) : categoryById(record?.categoryId || state.activeCategory) || state.categories[0];
  $('recordModalTitle').textContent = record ? 'Edit record' : 'Create record';
  $('recordId').value = record?.id || '';
  $('recordCategory').innerHTML = state.categories.map(c => `<option value="${c.id}" ${c.id === (record?.categoryId || cat?.id) ? 'selected' : ''}>${esc(c.name)}</option>`).join('');
  $('recordTitle').value = record?.title || '';
  $('recordNotes').value = record?.notes || '';
  $('recordTags').value = (record?.tags || []).join(', ');
  $('recordPriority').value = record?.priority || 'Medium';
  $('recordStatus').innerHTML = categoryStages(cat).map(s => `<option ${s === (record?.status || categoryStages(cat)[0]) ? 'selected' : ''}>${esc(s)}</option>`).join('');
  $('recordDueAt').value = localDT(record?.dueAt || '');
  $('recordReminderAt').value = localDT(record?.reminderAt || '');
  $('recordUrl').value = record?.url || '';
  $('recordPinned').checked = !!record?.pinned;
  $('recordFavorite').checked = !!record?.favorite;
  $('recordArchived').checked = !!record?.archived;
  $('saveAsTemplate').checked = false;
  $('dynamicFields').innerHTML = buildDynamicFields(cat, record?.values || {});
  $('attachmentPreview').innerHTML = attachmentPreview(record?.attachments || []);
  $('relationPicker').innerHTML = state.records.filter(r => !record || r.id !== record.id).slice(0, 18).map(r => `<label class="relation-chip"><input type="checkbox" value="${r.id}" class="relation-check" ${record?.relatedIds?.includes(r.id) ? 'checked' : ''}><span>${esc(r.title)}</span></label>`).join('');
  $('recordRelations').value = (record?.relatedIds || []).map(id => recordById(id)?.title).filter(Boolean).join(', ');
  $('recordPreview').innerHTML = record ? previewMarkup(record, cat) : `<div class="preview-title">New record</div><div class="preview-line">${esc(cat?.name || 'Choose a category')}</div><div class="preview-line">Keep it flexible. Add fields, docs, links, and follow-ups.</div>`;
  recordModal.show();
  bindRecordLivePreview();
}
function previewMarkup(record, cat) {
  const fields = categoryFields(cat).slice(0, 3).map(f => {
    const v = record.values?.[f.key];
    if (v === undefined || v === '' || v === null) return '';
    return `<div class="preview-line"><strong>${esc(f.label)}:</strong> ${esc(Array.isArray(v) ? v.join(', ') : String(v))}</div>`;
  }).filter(Boolean).join('');
  return `<div class="preview-title">${esc(record.title || 'Untitled')}</div><div class="preview-line">${esc(cat?.name || 'No category')}</div><div class="preview-line">${esc((record.notes || '').slice(0, 140) || 'No notes yet.')}</div>${fields}`;
}
function bindRecordLivePreview() {
  const form = $('recordForm');
  const update = () => {
    const temp = collectRecordData(true);
    $('recordPreview').innerHTML = previewMarkup(temp, categoryById(temp.categoryId));
  };
  if (form.dataset.previewBound !== '1') {
    form.addEventListener('input', update);
    form.addEventListener('change', update);
    form.dataset.previewBound = '1';
  }
  $('recordCategory').onchange = () => {
    const cat = categoryById($('recordCategory').value);
    $('recordStatus').innerHTML = categoryStages(cat).map(s => `<option>${esc(s)}</option>`).join('');
    $('dynamicFields').innerHTML = buildDynamicFields(cat, {});
    update();
  };
  update();
}
function collectRecordData(isPreview = false) {
  const categoryId = $('recordCategory').value;
  const data = {
    id: $('recordId').value || uid('rec'),
    categoryId,
    title: $('recordTitle').value.trim(),
    notes: $('recordNotes').value.trim(),
    tags: arrayify($('recordTags').value),
    priority: $('recordPriority').value,
    status: $('recordStatus').value,
    values: collectValues($('dynamicFields')),
    url: $('recordUrl').value.trim(),
    favorite: $('recordFavorite').checked,
    pinned: $('recordPinned').checked,
    archived: $('recordArchived').checked,
    dueAt: $('recordDueAt').value ? new Date($('recordDueAt').value).toISOString() : '',
    reminderAt: $('recordReminderAt').value ? new Date($('recordReminderAt').value).toISOString() : '',
    relatedIds: Array.from(document.querySelectorAll('.relation-check:checked')).map(x => x.value),
    attachments: isPreview ? (recordById($('recordId').value)?.attachments || []) : [],
  };
  return data;
}
async function saveRecord() {
  const record = collectRecordData(false);
  if (!record.title) return toast('Add a title before saving.', 'danger');
  const existing = await getById(STORE.records, record.id);
  record.createdAt = existing?.createdAt || nowISO();
  record.updatedAt = nowISO();
  record.attachments = state.selectedAttachments.length ? [...(existing?.attachments || []), ...state.selectedAttachments] : (existing?.attachments || []);
  await put(STORE.records, record);
  if ($('saveAsTemplate').checked) {
    await put(STORE.templates, { id: uid('tpl'), name: record.title, categoryId: record.categoryId, values: record.values, notes: record.notes, tags: record.tags, createdAt: nowISO(), updatedAt: nowISO() });
  }
  await logActivity(existing ? 'update' : 'create', `${existing ? 'Updated' : 'Created'} "${record.title}"`, record.id);
  await reloadData();
  recordModal.hide();
  renderAll();
  $('lastSavedPill').textContent = 'Saved now';
  toast(`Saved ${record.title}`);
}
async function deleteRecord(id) {
  const record = recordById(id || state.currentRecordId);
  if (!record) return;
  if (!confirm(`Delete "${record.title}"?`)) return;
  await remove(STORE.records, record.id);
  await logActivity('delete', `Deleted "${record.title}"`, record.id);
  await reloadData();
  recordModal.hide();
  renderAll();
  toast('Record deleted');
}
async function duplicateRecord(id) {
  const record = recordById(id);
  if (!record) return;
  const copy = { ...record, id: uid('rec'), title: `${record.title} (copy)`, createdAt: nowISO(), updatedAt: nowISO(), favorite: false, pinned: false };
  await put(STORE.records, copy);
  await logActivity('create', `Duplicated "${record.title}"`, copy.id);
  await reloadData();
  renderAll();
  toast('Record duplicated');
}
async function toggleFlag(id, key) {
  const record = recordById(id);
  if (!record) return;
  record[key] = !record[key];
  record.updatedAt = nowISO();
  await put(STORE.records, record);
  await logActivity('update', `${record[key] ? 'Enabled' : 'Disabled'} ${key} on "${record.title}"`, record.id);
  await reloadData();
  renderAll();
}

function fieldRow(field = {}) {
  return `
    <div class="field-row">
      <input class="form-control field-label" placeholder="Label" value="${esc(field.label || '')}">
      <input class="form-control field-name" placeholder="Key (slug)" value="${esc(field.key || '')}">
      <select class="form-select field-type">
        ${['text','number','date','time','datetime','dropdown','checkbox','rating','file','image','location','rich'].map(type => `<option value="${type}" ${type === (field.type || 'text') ? 'selected' : ''}>${titleCase(type)}</option>`).join('')}
      </select>
      <button type="button" class="btn btn-soft remove-btn"><i class="bi bi-trash"></i></button>
      <textarea class="form-control field-options mt-2 d-none" placeholder="Options, one per line">${esc((field.options || []).join('\n'))}</textarea>
    </div>
  `;
}
function openCategoryModal(categoryId = null) {
  state.currentCategoryId = categoryId;
  const cat = categoryId ? categoryById(categoryId) : null;
  $('categoryModalTitle').textContent = cat ? 'Edit category' : 'Create category';
  $('categoryId').value = cat?.id || '';
  $('categoryName').value = cat?.name || '';
  $('categoryIcon').value = cat?.icon || 'bi-folder2';
  $('categoryColor').value = cat?.color || '#7c8cff';
  $('categoryDescription').value = cat?.description || '';
  $('categoryStages').value = (cat?.stages || DEFAULT_STATUS).join(', ');
  $('categoryView').value = cat?.view || 'grid';
  $('fieldBuilder').innerHTML = (cat?.fields || []).length ? cat.fields.map(fieldRow).join('') : fieldRow();
  bindFieldRows();
  renderCategoryPreview();
  categoryModal.show();
}
function bindFieldRows() {
  $('fieldBuilder').querySelectorAll('.field-row').forEach(row => {
    const type = row.querySelector('.field-type');
    const options = row.querySelector('.field-options');
    const toggle = () => options.classList.toggle('d-none', !['dropdown','select'].includes(type.value));
    type.onchange = toggle;
    toggle();
    row.querySelector('.remove-btn').onclick = () => row.remove();
  });
}
function renderCategoryPreview() {
  $('categoryPreview').innerHTML = `
    <div class="preview-title">${esc($('categoryName').value || 'Untitled category')}</div>
    <div class="preview-line">Icon: ${esc($('categoryIcon').value || 'bi-folder2')}</div>
    <div class="preview-line">${esc($('categoryDescription').value || 'Describe the system you want to track.')}</div>
    <div class="preview-line">Statuses: ${esc(($('categoryStages').value || '').split(',').filter(Boolean).join(' • ') || 'Default')}</div>
  `;
}
async function saveCategory() {
  const name = $('categoryName').value.trim();
  if (!name) return toast('Category name is required.', 'danger');
  const existing = await getById(STORE.categories, $('categoryId').value);
  const cat = {
    id: $('categoryId').value || uid('cat'),
    name,
    icon: $('categoryIcon').value.trim() || 'bi-folder2',
    color: $('categoryColor').value || '#7c8cff',
    description: $('categoryDescription').value.trim(),
    stages: arrayify($('categoryStages').value).length ? arrayify($('categoryStages').value) : DEFAULT_STATUS,
    view: $('categoryView').value,
    fields: collectCategoryFields(),
    createdAt: existing?.createdAt || nowISO(),
    updatedAt: nowISO(),
  };
  await put(STORE.categories, cat);
  await logActivity(existing ? 'category' : 'category', `${existing ? 'Updated' : 'Created'} category "${cat.name}"`, cat.id);
  await reloadData();
  categoryModal.hide();
  renderAll();
  toast(`Category saved: ${cat.name}`);
}
function collectCategoryFields() {
  return Array.from($('fieldBuilder').querySelectorAll('.field-row')).map(row => {
    const label = row.querySelector('.field-label').value.trim();
    const keyRaw = row.querySelector('.field-name').value.trim();
    const key = keyRaw || label.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    const type = row.querySelector('.field-type').value;
    const options = row.querySelector('.field-options').value.split('\n').map(s => s.trim()).filter(Boolean);
    return { id: uid('f'), label, key, type, options };
  }).filter(f => f.label || f.key);
}
async function deleteCategory() {
  const id = $('categoryId').value;
  const cat = categoryById(id);
  if (!cat) return;
  if (!confirm(`Delete category "${cat.name}"? Records will stay but be uncategorized.`)) return;
  const fallback = state.categories.find(c => c.id !== id)?.id || '';
  const affected = state.records.filter(r => r.categoryId === id);
  for (const r of affected) {
    r.categoryId = fallback;
    r.updatedAt = nowISO();
    await put(STORE.records, r);
  }
  await remove(STORE.categories, id);
  await logActivity('delete', `Deleted category "${cat.name}"`, id);
  await reloadData();
  categoryModal.hide();
  renderAll();
  toast('Category deleted');
}

function openSettings() {
  $('themeSelect').value = localStorage.getItem('notetrack.theme') || 'dark';
  $('accentPicker').value = localStorage.getItem('notetrack.accent') || '#7c8cff';
  $('translateEndpoint').value = localStorage.getItem('notetrack.translateEndpoint') || '/api/translate.php';
  $('defaultLanguage').innerHTML = LANGUAGES.map(([code, label]) => `<option value="${code}">${label}</option>`).join('');
  $('defaultLanguage').value = localStorage.getItem('notetrack.lang') || 'en';
  settingsModal.show();
}
function openTranslate() {
  $('translateFrom').innerHTML = LANGUAGES.map(([code, label]) => `<option value="${code}">${label}</option>`).join('');
  $('translateTo').innerHTML = LANGUAGES.map(([code, label]) => `<option value="${code}">${label}</option>`).join('');
  $('translateFrom').value = 'auto';
  $('translateTo').value = localStorage.getItem('notetrack.lang') || 'en';
  $('translateScope').value = 'notes';
  $('translateHint').textContent = `Endpoint: ${localStorage.getItem('notetrack.translateEndpoint') || '/api/translate.php'} • keep Google credentials on the server side only.`;
  translateModal.show();
}
async function translateText() {
  const endpoint = localStorage.getItem('notetrack.translateEndpoint') || '/api/translate.php';
  const text = $('translateInput').value.trim();
  if (!text) return toast('Add text to translate.', 'danger');
  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, source: $('translateFrom').value, target: $('translateTo').value }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    $('translateOutput').value = data.translatedText || data.text || '';
    toast('Translation complete');
  } catch (err) {
    console.error(err);
    toast('Translation endpoint unavailable.', 'danger');
  }
}
function useRecordTextForTranslate() {
  const record = state.currentRecordId ? recordById(state.currentRecordId) : null;
  if (!record) return toast('Open a record first.', 'danger');
  $('translateInput').value = `${record.title}\n\n${record.notes}`;
}
function applyTranslationToRecord() {
  const record = state.currentRecordId ? recordById(state.currentRecordId) : null;
  const out = $('translateOutput').value.trim();
  if (!record) return toast('Open a record first.', 'danger');
  if (!out) return toast('No translated text yet.', 'danger');
  const scope = $('translateScope').value;
  if (scope === 'title' || scope === 'both') record.title = out.split('\n')[0].slice(0, 120);
  if (scope === 'notes' || scope === 'both') record.notes = out;
  record.updatedAt = nowISO();
  put(STORE.records, record).then(async () => {
    await logActivity('translate', `Translated "${record.title}"`, record.id);
    await reloadData();
    renderAll();
    recordModal.hide();
    toast('Applied translation');
  });
}
async function exportJson() {
  const bundle = await exportBundle();
  const blob = new Blob([JSON.stringify(bundle, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `notetrack-backup-${new Date().toISOString().slice(0,10)}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
  toast('Backup exported');
}
async function importJson(file) {
  const bundle = JSON.parse(await file.text());
  await importBundle(bundle);
  await reloadData();
  renderAll();
  toast('Backup imported');
}
async function resetDemo() {
  if (!confirm('Reset everything and reload the starter workspace?')) return;
  await importBundle({ categories: [], records: [], templates: [], activity: [], queue: [] });
  await seedIfEmpty();
  await reloadData();
  renderAll();
  toast('Demo reset complete');
}
async function reloadData() {
  state.categories = await getAll(STORE.categories);
  state.records = await getAll(STORE.records);
  state.templates = await getAll(STORE.templates);
  state.activity = (await getAll(STORE.activity)).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}
async function startQuickCreate() {
  if (!state.categories.length) return openCategoryModal();
  pickerModal.show();
}
function bindGlobal() {
  $('btnQuickCreate').onclick = startQuickCreate;
  $('btnHeroCreate').onclick = startQuickCreate;
  $('btnAddRecord').onclick = startQuickCreate;
  $('btnNewNote').onclick = startQuickCreate;
  $('btnNewDoc').onclick = startQuickCreate;
  $('btnNewReminder').onclick = () => { startQuickCreate(); setTimeout(() => $('recordReminderAt').focus(), 250); };
  $('btnNewWorkflow').onclick = () => openCategoryModal();
  $('btnCreateCategory').onclick = () => openCategoryModal();
  $('btnCategoryManager').onclick = () => openCategoryModal();
  $('btnDrawerCategory').onclick = () => openCategoryModal();
  $('btnSettings').onclick = openSettings;
  $('btnManageData').onclick = openSettings;
  $('btnExport').onclick = exportJson;
  $('btnManageTemplates').onclick = () => templatesModal.show();
  $('btnTemplates').onclick = () => templatesModal.show();
  $('btnTranslateOpen').onclick = openTranslate;
  $('btnRecordTranslate').onclick = openTranslate;
  $('btnThemeToggle').onclick = () => applyTheme((document.documentElement.dataset.theme || 'dark') === 'dark' ? 'light' : 'dark');
  $('btnRefresh').onclick = renderAll;
  $('btnMobileMenu').onclick = () => mobileDrawer.show();
  $('btnMobileAdd').onclick = startQuickCreate;
  $('btnDrawerAdd').onclick = startQuickCreate;

  $('searchInput').addEventListener('input', e => { state.search = e.target.value; renderRecords(); });
  $('tagFilter').addEventListener('input', e => { state.filters.tag = e.target.value; renderRecords(); });
  $('statusFilter').addEventListener('change', e => { state.filters.status = e.target.value; renderRecords(); });
  $('priorityFilter').addEventListener('change', e => { state.filters.priority = e.target.value; renderRecords(); });
  $('viewSelect').addEventListener('change', e => { state.view = e.target.value; localStorage.setItem('notetrack.view', state.view); renderRecords(); });
  $('sortSelect').addEventListener('change', e => { state.sort = e.target.value; localStorage.setItem('notetrack.sort', state.sort); renderRecords(); });

  $('btnOnlyFav').onclick = () => { state.filters.onlyFav = !state.filters.onlyFav; $('btnOnlyFav').classList.toggle('active', state.filters.onlyFav); renderRecords(); };
  $('btnOnlyPinned').onclick = () => { state.filters.onlyPinned = !state.filters.onlyPinned; $('btnOnlyPinned').classList.toggle('active', state.filters.onlyPinned); renderRecords(); };
  $('btnOnlyDue').onclick = () => { state.filters.onlyDue = !state.filters.onlyDue; $('btnOnlyDue').classList.toggle('active', state.filters.onlyDue); renderRecords(); };
  $('btnClearFilters').onclick = () => { state.search = ''; state.filters = { status:'', priority:'', tag:'', onlyFav:false, onlyPinned:false, onlyDue:false }; $('searchInput').value=''; $('tagFilter').value=''; $('statusFilter').value=''; $('priorityFilter').value=''; ['btnOnlyFav','btnOnlyPinned','btnOnlyDue'].forEach(id => $(id).classList.remove('active')); renderRecords(); };

  document.querySelectorAll('[data-nav]').forEach(btn => {
    btn.onclick = () => {
      state.activeScope = btn.dataset.nav;
      state.activeCategory = 'all';
      localStorage.setItem('notetrack.category', 'all');
      refreshNav();
      renderAll();
      mobileDrawer?.hide();
    };
  });
  document.querySelectorAll('[data-mobile-nav]').forEach(btn => {
    btn.onclick = () => {
      state.activeScope = btn.dataset.mobileNav;
      state.activeCategory = 'all';
      localStorage.setItem('notetrack.category', 'all');
      refreshNav();
      renderAll();
    };
  });

  $('btnSaveRecord').onclick = e => { e.preventDefault(); saveRecord(); };
  $('btnDeleteRecord').onclick = () => deleteRecord($('recordId').value);
  $('btnRecordDuplicate').onclick = () => { if ($('recordId').value) duplicateRecord($('recordId').value); };
  $('btnRecordArchive').onclick = async () => {
    const rec = recordById($('recordId').value);
    if (!rec) return;
    rec.archived = !rec.archived;
    rec.updatedAt = nowISO();
    $('recordArchived').checked = rec.archived;
    await put(STORE.records, rec);
    await logActivity('update', `${rec.archived ? 'Archived' : 'Restored'} "${rec.title}"`, rec.id);
    await reloadData();
    renderAll();
    toast(rec.archived ? 'Record archived' : 'Record restored');
  };
  $('recordForm').addEventListener('submit', e => { e.preventDefault(); saveRecord(); });
  $('categoryForm').addEventListener('submit', e => { e.preventDefault(); saveCategory(); });
  $('categoryName').addEventListener('input', renderCategoryPreview);
  $('categoryIcon').addEventListener('input', renderCategoryPreview);
  $('categoryDescription').addEventListener('input', renderCategoryPreview);
  $('categoryStages').addEventListener('input', renderCategoryPreview);
  $('recordCategory').addEventListener('change', () => {
    const cat = categoryById($('recordCategory').value);
    $('recordStatus').innerHTML = categoryStages(cat).map(s => `<option>${esc(s)}</option>`).join('');
    $('dynamicFields').innerHTML = buildDynamicFields(cat, {});
  });
  $('recordFiles').addEventListener('change', async e => {
    const files = Array.from(e.target.files || []);
    state.selectedAttachments = [];
    for (const file of files) {
      const dataUrl = await fileToDataUrl(file);
      state.selectedAttachments.push({ id: uid('att'), name: file.name, type: file.type, size: file.size, dataUrl });
    }
    $('attachmentPreview').innerHTML = attachmentPreview(state.selectedAttachments);
  });
  $('btnUseRecordText').onclick = useRecordTextForTranslate;
  $('btnDoTranslate').onclick = translateText;
  $('btnApplyTranslation').onclick = applyTranslationToRecord;
  $('btnExportJson').onclick = exportJson;
  $('btnResetDemo').onclick = resetDemo;
  $('importJson').addEventListener('change', e => { if (e.target.files?.[0]) importJson(e.target.files[0]); });
  $('btnAddField').onclick = () => { $('fieldBuilder').insertAdjacentHTML('beforeend', fieldRow()); bindFieldRows(); };
  $('btnDeleteCategory').onclick = deleteCategory;

  $('fieldBuilder').addEventListener('input', renderCategoryPreview);
  $('fieldBuilder').addEventListener('change', renderCategoryPreview);

  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); $('searchInput').focus(); }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'n') { e.preventDefault(); startQuickCreate(); }
  });
}
async function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}
function attachmentPreview(files) {
  if (!files.length) return '<div class="muted-copy">No attachments yet.</div>';
  return files.map(f => `<div class="attach-chip">${f.dataUrl?.startsWith('data:image') ? `<img class="attach-thumb" src="${f.dataUrl}" alt="">` : '<i class="bi bi-paperclip"></i>'}<span>${esc(f.name)}</span></div>`).join('');
}
function bindTemplateActions() {
  $('templatesList').addEventListener('click', async e => {
    const use = e.target.closest('[data-use-template]')?.dataset.useTemplate;
    const del = e.target.closest('[data-delete-template]')?.dataset.deleteTemplate;
    if (use) {
      const t = templateById(use);
      if (!t) return;
      openRecordModal(null, t.categoryId);
      $('recordTitle').value = t.name;
      $('recordNotes').value = t.notes || '';
      $('recordTags').value = (t.tags || []).join(', ');
      $('dynamicFields').querySelectorAll('[data-field-key]').forEach(input => {
        const key = input.dataset.fieldKey;
        if (t.values && key in t.values) {
          if (input.type === 'checkbox') input.checked = !!t.values[key];
          else input.value = t.values[key];
        }
      });
      templatesModal.hide();
    }
    if (del) {
      await remove(STORE.templates, del);
      await logActivity('delete', 'Deleted template', del);
      await reloadData();
      renderAll();
      toast('Template deleted');
    }
  });
}
function openTemplateModal() { templatesModal.show(); }
function bindModalHooks() {}
async function registerSW() {
  if ('serviceWorker' in navigator) {
    try { await navigator.serviceWorker.register('sw.js'); } catch (e) { console.warn('SW failed', e); }
  }
}
async function remindersTick() {
  if ('Notification' in window && Notification.permission === 'granted') {
    const due = state.records.filter(r => r.reminderAt && new Date(r.reminderAt).getTime() <= Date.now() && !r.archived);
    due.slice(0, 2).forEach(r => new Notification('NoteTrack reminder', { body: r.title }));
  }
}
function bindCategoryFormExtras() {
  $('fieldBuilder').addEventListener('click', (e) => {
    if (e.target.closest('.remove-btn')) e.target.closest('.field-row')?.remove();
  });
}
async function init() {
  recordModal = new bootstrap.Modal($('recordModal'));
  categoryModal = new bootstrap.Modal($('categoryModal'));
  settingsModal = new bootstrap.Modal($('settingsModal'));
  translateModal = new bootstrap.Modal($('translateModal'));
  templatesModal = new bootstrap.Modal($('templatesModal'));
  pickerModal = new bootstrap.Modal($('categoryPickerModal'));
  mobileDrawer = new bootstrap.Offcanvas($('mobileDrawer'));

  loadPreferences();
  setConnection(navigator.onLine);
  window.addEventListener('online', () => { setConnection(true); toast('Back online'); });
  window.addEventListener('offline', () => { setConnection(false); toast('Working offline', 'danger'); });

  bindGlobal();
  bindTemplateActions();
  bindCategoryFormExtras();

  $('themeSelect').addEventListener('change', e => applyTheme(e.target.value));
  $('accentPicker').addEventListener('input', e => applyAccent(e.target.value));
  $('defaultLanguage').addEventListener('change', e => localStorage.setItem('notetrack.lang', e.target.value));
  $('translateEndpoint').addEventListener('change', e => localStorage.setItem('notetrack.translateEndpoint', e.target.value.trim()));

  await seedIfEmpty();
  await reloadData();
  renderAll();
  await registerSW();
  await remindersTick();

  if ('Notification' in window && Notification.permission === 'default') {
    setTimeout(() => Notification.requestPermission?.(), 1800);
  }
}

document.addEventListener('DOMContentLoaded', init);
