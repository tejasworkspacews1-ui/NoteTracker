const DB_NAME = 'notetrack-db';
const DB_VERSION = 1;

const STORE = {
  categories: 'categories',
  records: 'records',
  templates: 'templates',
  activity: 'activity',
  queue: 'queue',
};

function nowISO() {
  return new Date().toISOString();
}

function uid(prefix = 'id') {
  if (window.crypto?.randomUUID) return `${prefix}_${crypto.randomUUID()}`;
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36)}`;
}

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      for (const storeName of Object.values(STORE)) {
        if (!db.objectStoreNames.contains(storeName)) {
          const store = db.createObjectStore(storeName, { keyPath: 'id' });
          store.createIndex('updatedAt', 'updatedAt', { unique: false });
          store.createIndex('createdAt', 'createdAt', { unique: false });
          store.createIndex('categoryId', 'categoryId', { unique: false });
        }
      }
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function getAll(storeName) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const request = tx.objectStore(storeName).getAll();
    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error);
  });
}

async function getById(storeName, id) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const request = tx.objectStore(storeName).get(id);
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
}

async function put(storeName, value) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const request = tx.objectStore(storeName).put(value);
    request.onsuccess = () => resolve(value);
    request.onerror = () => reject(request.error);
  });
}

async function remove(storeName, id) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const request = tx.objectStore(storeName).delete(id);
    request.onsuccess = () => resolve(true);
    request.onerror = () => reject(request.error);
  });
}

async function clearStore(storeName) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const request = tx.objectStore(storeName).clear();
    request.onsuccess = () => resolve(true);
    request.onerror = () => reject(request.error);
  });
}

async function count(storeName) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const request = tx.objectStore(storeName).count();
    request.onsuccess = () => resolve(request.result || 0);
    request.onerror = () => reject(request.error);
  });
}

function defaultCategories() {
  const stamp = nowISO();
  return [
    {
      id: uid('cat'),
      name: 'Projects',
      icon: 'bi-briefcase',
      color: '#7c8cff',
      description: 'Work, startup ideas, personal builds, and deliverables.',
      view: 'kanban',
      stages: ['Backlog', 'Active', 'Blocked', 'Done'],
      fields: [
        { id: uid('f'), label: 'Owner', key: 'owner', type: 'text' },
        { id: uid('f'), label: 'Value', key: 'value', type: 'number' },
        { id: uid('f'), label: 'Website', key: 'website', type: 'url' },
      ],
      createdAt: stamp,
      updatedAt: stamp,
    },
    {
      id: uid('cat'),
      name: 'Life Admin',
      icon: 'bi-inboxes',
      color: '#22c55e',
      description: 'Bills, IDs, receipts, appointments, and practical life tracking.',
      view: 'list',
      stages: ['To do', 'Waiting', 'Done'],
      fields: [
        { id: uid('f'), label: 'Due date', key: 'due', type: 'date' },
        { id: uid('f'), label: 'Priority score', key: 'score', type: 'rating' },
      ],
      createdAt: stamp,
      updatedAt: stamp,
    },
    {
      id: uid('cat'),
      name: 'Content Ideas',
      icon: 'bi-camera-reels',
      color: '#f97316',
      description: 'Reels, posts, scripts, hooks, thumbnails, and publishing notes.',
      view: 'grid',
      stages: ['Idea', 'Draft', 'Review', 'Scheduled', 'Published'],
      fields: [
        { id: uid('f'), label: 'Format', key: 'format', type: 'select', options: ['Reel', 'Carousel', 'Video', 'Article', 'Thread'] },
        { id: uid('f'), label: 'Asset', key: 'asset', type: 'file' },
      ],
      createdAt: stamp,
      updatedAt: stamp,
    }
  ];
}

function defaultRecords(categories) {
  const stamp = nowISO();
  const find = name => categories.find(c => c.name === name);
  return [
    {
      id: uid('rec'),
      categoryId: find('Projects')?.id,
      title: 'NoteTrack v1 concept',
      notes: 'A universal tracker with custom categories, flexible fields, and offline-first behavior.',
      tags: ['startup', 'product', 'design'],
      status: 'Active',
      priority: 'High',
      values: { owner: 'Solo build', value: 1000, website: 'https://example.com' },
      attachments: [],
      relatedIds: [],
      favorite: true,
      pinned: true,
      archived: false,
      dueAt: stamp,
      reminderAt: '',
      url: 'https://example.com',
      createdAt: stamp,
      updatedAt: stamp,
    },
    {
      id: uid('rec'),
      categoryId: find('Life Admin')?.id,
      title: 'Renew documents',
      notes: 'Keep IDs, payments, and renewal dates in one place.',
      tags: ['admin', 'urgent'],
      status: 'To do',
      priority: 'Critical',
      values: { due: new Date(Date.now() + 86400000 * 3).toISOString().slice(0, 10), score: 5 },
      attachments: [],
      relatedIds: [],
      favorite: false,
      pinned: false,
      archived: false,
      dueAt: '',
      reminderAt: '',
      url: '',
      createdAt: stamp,
      updatedAt: stamp,
    },
  ];
}

async function seedIfEmpty() {
  const categories = await getAll(STORE.categories);
  if (categories.length) return false;
  const cats = defaultCategories();
  for (const category of cats) await put(STORE.categories, category);
  for (const record of defaultRecords(cats)) await put(STORE.records, record);
  await logActivity('seed', 'Loaded starter workspace', cats[0]?.id);
  return true;
}

async function logActivity(type, message, entityId = '') {
  await put(STORE.activity, { id: uid('act'), type, message, entityId, createdAt: nowISO() });
}

async function exportBundle() {
  const [categories, records, templates, activity, queue] = await Promise.all([
    getAll(STORE.categories), getAll(STORE.records), getAll(STORE.templates), getAll(STORE.activity), getAll(STORE.queue),
  ]);
  return { version: 1, exportedAt: nowISO(), categories, records, templates, activity, queue };
}

async function importBundle(bundle) {
  if (!bundle || typeof bundle !== 'object') throw new Error('Invalid bundle');
  const payload = {
    categories: Array.isArray(bundle.categories) ? bundle.categories : [],
    records: Array.isArray(bundle.records) ? bundle.records : [],
    templates: Array.isArray(bundle.templates) ? bundle.templates : [],
    activity: Array.isArray(bundle.activity) ? bundle.activity : [],
    queue: Array.isArray(bundle.queue) ? bundle.queue : [],
  };
  await clearStore(STORE.categories);
  await clearStore(STORE.records);
  await clearStore(STORE.templates);
  await clearStore(STORE.activity);
  await clearStore(STORE.queue);
  for (const item of payload.categories) await put(STORE.categories, item);
  for (const item of payload.records) await put(STORE.records, item);
  for (const item of payload.templates) await put(STORE.templates, item);
  for (const item of payload.activity) await put(STORE.activity, item);
  for (const item of payload.queue) await put(STORE.queue, item);
}

export {
  STORE, uid, nowISO, openDatabase,
  getAll, getById, put, remove, clearStore, count,
  seedIfEmpty, logActivity, exportBundle, importBundle
};
